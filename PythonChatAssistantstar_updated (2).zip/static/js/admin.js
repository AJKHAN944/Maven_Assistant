// Admin Panel JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Color picker preview
    const colorInputs = document.querySelectorAll('input[type="color"]');
    colorInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateColorPreview();
        });
    });

    // Logo preview
    const logoInput = document.getElementById('logo');
    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const logoPreview = document.getElementById('logoPreview');
                    if (logoPreview) {
                        logoPreview.src = e.target.result;
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Auto-save functionality
    let autoSaveTimeout;
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            clearTimeout(autoSaveTimeout);
            autoSaveTimeout = setTimeout(() => {
                showAutoSaveIndicator();
            }, 2000);
        });
    });

    // Sidebar toggle for mobile
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('show');
        });
    }
});

function updateColorPreview() {
    const colors = {
        primary: document.getElementById('primary_color').value,
        chatbot: document.getElementById('chatbot_color').value,
        user: document.getElementById('user_color').value,
        button: document.getElementById('button_color').value
    };

    // Update CSS variables for preview
    document.documentElement.style.setProperty('--primary-bg', colors.primary);
    document.documentElement.style.setProperty('--chatbot-msg', colors.chatbot);
    document.documentElement.style.setProperty('--user-msg', colors.user);
    document.documentElement.style.setProperty('--button-color', colors.button);
}

function showAutoSaveIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'alert alert-info alert-dismissible fade show position-fixed';
    indicator.style.top = '20px';
    indicator.style.right = '20px';
    indicator.style.zIndex = '9999';
    indicator.innerHTML = `
        <i class="fas fa-save"></i> Auto-save ready
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(indicator);

    setTimeout(() => {
        indicator.remove();
    }, 3000);
}

function viewLead(id, name, email, phone, category, message, date) {
    // Populate modal with lead details
    document.getElementById('leadName').textContent = name;
    document.getElementById('leadEmail').textContent = email;
    document.getElementById('leadPhone').textContent = phone;
    document.getElementById('leadCategory').textContent = category;
    document.getElementById('leadMessage').textContent = message;
    document.getElementById('leadDate').textContent = date;

    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('leadModal'));
    modal.show();
}

function deleteLead(id) {
    if (confirm('Are you sure you want to delete this lead?')) {
        fetch(`/delete_lead/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error deleting lead');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting lead');
        });
    }
}

function exportLeads() {
    // Create CSV export
    const table = document.querySelector('.table');
    if (!table) return;

    const rows = Array.from(table.querySelectorAll('tr'));
    const csvContent = rows.map(row => {
        const cols = Array.from(row.querySelectorAll('th, td'));
        return cols.slice(0, -1).map(col => `"${col.textContent.trim()}"`).join(',');
    }).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'leads.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}

// Real-time stats update
function updateStats() {
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            document.getElementById('totalLeads').textContent = data.total_leads;
            document.getElementById('todayLeads').textContent = data.today_leads;
            document.getElementById('conversionRate').textContent = data.conversion_rate + '%';
        })
        .catch(error => console.error('Error updating stats:', error));
}

// Update stats every 30 seconds
setInterval(updateStats, 30000);

// Email recipients management
function addEmailRecipient() {
    const emailInput = document.getElementById('new_email');
    const email = emailInput.value.trim();
    
    if (!email) {
        alert('Please enter an email address');
        return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
    }
    
    // Check if email already exists
    const existingEmails = document.querySelectorAll('.email-address');
    for (let existingEmail of existingEmails) {
        if (existingEmail.textContent.trim() === email) {
            alert('This email address is already added');
            return;
        }
    }
    
    // Add new email item
    const emailList = document.getElementById('email-list');
    const emailItem = document.createElement('div');
    emailItem.className = 'email-item';
    emailItem.innerHTML = `
        <span class="email-address">${email}</span>
        <button type="button" class="btn btn-sm btn-danger" onclick="removeEmailRecipient(this)">
            <i class="fas fa-trash"></i>
        </button>
    `;
    
    emailList.appendChild(emailItem);
    emailInput.value = '';
    
    // Update hidden input
    updateEmailRecipientsInput();
}

function removeEmailRecipient(button) {
    const emailItem = button.parentElement;
    emailItem.remove();
    
    // Update hidden input
    updateEmailRecipientsInput();
}

function updateEmailRecipientsInput() {
    const emailAddresses = document.querySelectorAll('.email-address');
    const emails = Array.from(emailAddresses).map(el => el.textContent.trim());
    document.getElementById('email_recipients').value = emails.join(', ');
}

// Allow Enter key to add email
document.addEventListener('keydown', function(e) {
    if (e.target.id === 'new_email' && e.key === 'Enter') {
        e.preventDefault();
        addEmailRecipient();
    }
    if (e.target.id === 'email_input' && e.key === 'Enter') {
        e.preventDefault();
        addEmailFromTab();
    }
});

// Email management functions for the dedicated email tab
function addEmailFromTab() {
    const emailInput = document.getElementById('email_input');
    const email = emailInput.value.trim();
    
    if (!email) {
        alert('Please enter an email address');
        return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
    }
    
    // Check if email already exists
    const existingEmails = document.querySelectorAll('#email_display_list .email-address');
    for (let existingEmail of existingEmails) {
        if (existingEmail.textContent.trim() === email) {
            alert('This email address is already added');
            return;
        }
    }
    
    // Add new email item
    const emailList = document.getElementById('email_display_list');
    const emailItem = document.createElement('div');
    emailItem.className = 'email-item';
    emailItem.innerHTML = `
        <span class="email-address">${email}</span>
        <button type="button" class="btn btn-sm btn-danger" onclick="removeEmailFromTab(this)">
            <i class="fas fa-trash"></i>
        </button>
    `;
    
    emailList.appendChild(emailItem);
    emailInput.value = '';
}

function removeEmailFromTab(button) {
    const emailItem = button.parentElement;
    emailItem.remove();
}

function saveEmailSettings() {
    const emailAddresses = document.querySelectorAll('#email_display_list .email-address');
    const emails = Array.from(emailAddresses).map(el => el.textContent.trim());
    
    if (emails.length === 0) {
        alert('Please add at least one email address');
        return;
    }
    
    const emailRecipientsString = emails.join(', ');
    
    // Save via AJAX
    fetch('/admin/save_email_settings', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `email_recipients=${encodeURIComponent(emailRecipientsString)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            const alertDiv = document.createElement('div');
            alertDiv.className = 'alert alert-success alert-dismissible fade show';
            alertDiv.innerHTML = `
                <i class="fas fa-check-circle"></i> Email settings saved successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            document.querySelector('#email .card-body').insertBefore(alertDiv, document.querySelector('#email .card-body').firstChild);
            
            // Update the settings tab as well
            const settingsEmailInput = document.getElementById('email_recipients');
            if (settingsEmailInput) {
                settingsEmailInput.value = emailRecipientsString;
            }
        } else {
            alert('Error saving email settings: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error saving email settings');
    });
}
