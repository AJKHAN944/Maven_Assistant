// Chatbot State Management
class ChatbotState {
    constructor() {
        this.currentStep = 0;
        this.language = 'en';
        this.formData = {};
        this.translations = {};
        this.settings = {};
        this.isTyping = false;
        this.isInterrupted = false;
        this.steps = [
            'greeting',
            'name',
            'email',
            'phone',
            'dropdown',
            'message',
            'confirmation'
        ];
        this.init();
    }

    async init() {
        await this.loadTranslations();
        await this.loadSettings();
        this.setupEventListeners();
        this.applySettings();
        this.startConversation();
    }

    async loadTranslations() {
        try {
            const response = await fetch(`/get_translations/${this.language}`);
            this.translations = await response.json();
        } catch (error) {
            console.error('Failed to load translations:', error);
            this.translations = this.getDefaultTranslations();
        }
    }

    async loadSettings() {
        try {
            const response = await fetch('/get_settings');
            this.settings = await response.json();
        } catch (error) {
            console.error('Failed to load settings:', error);
            this.settings = this.getDefaultSettings();
        }
    }

    getDefaultTranslations() {
        return {
            greeting: "Hi, I'm Maven and I'm here to help. Before I get you to one of our counselors, what's your name?",
            name_prompt: "What's your name?",
            email_prompt: "What's your email address?",
            phone_prompt: "What's your phone number?",
            dropdown_prompt: "How can we help you today?",
            message_prompt: "Please tell us more about your inquiry:",
            confirmation: "Awesome, we will be in touch soon. If you need to call us now, our number is: ",
            interruption_response: "Great question! Unfortunately, I'm a robot so I am pre-programmed to get you to a human. Can you please answer these questions for me for faster, more efficient service?",
            yes: "Yes",
            submit: "Submit",
            send: "Send",
            typing: "Maven is typing...",
            success_title: "Success!",
            success_message: "Your information has been submitted successfully!",
            contact_info: "We'll be in touch soon."
        };
    }

    getDefaultSettings() {
        return {
            counselor_title: "counselors",
            phone_number: "(555) 123-4567",
            dropdown_options: ["General Inquiry", "Technical Support", "Billing", "Other"],
            logo_position: "top-left",
            primary_color: "#0d1b2a",
            chatbot_color: "#2e7d32",
            user_color: "#e0e1dd",
            button_color: "#4db6ac"
        };
    }

    setupEventListeners() {
        const langToggle = document.getElementById('langToggle');
        langToggle.addEventListener('click', () => this.toggleLanguage());

        // Handle form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.classList.contains('chat-form')) {
                e.preventDefault();
                this.handleFormSubmission(e.target);
            }
        });

        // Handle button clicks
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('chat-btn')) {
                this.handleButtonClick(e.target);
            }
        });

        // Handle interruptions
        document.addEventListener('keydown', (e) => {
            if (e.key === '?' && this.currentStep > 0 && this.currentStep < this.steps.length - 1) {
                this.handleInterruption();
            }
        });
    }

    applySettings() {
        // Apply colors
        document.documentElement.style.setProperty('--primary-bg', this.settings.primary_color);
        document.documentElement.style.setProperty('--chatbot-msg', this.settings.chatbot_color);
        document.documentElement.style.setProperty('--user-msg', this.settings.user_color);
        document.documentElement.style.setProperty('--button-color', this.settings.button_color);

        // Load multiple logos
        this.loadLogos();

        // Update UI text
        document.getElementById('chatTitle').textContent = this.translations.chat_title || 'Maven Assistant';
        document.getElementById('statusText').textContent = this.translations.status_online || 'Online';
        document.getElementById('typingText').textContent = this.translations.typing;
        
        // Update language toggle button
        const langText = document.getElementById('langText');
        langText.textContent = this.translations.language_toggle || (this.language === 'en' ? 'ES' : 'EN');
    }

    loadLogos() {
        const logosContainer = document.getElementById('logosRow');
        const logoContainer = document.getElementById('logoContainer');
        
        // Clear existing logos
        logosContainer.innerHTML = '';
        
        // Check and load each logo
        const logos = [
            { url: this.settings.logo_url_1, enabled: this.settings.logo_1_enabled },
            { url: this.settings.logo_url_2, enabled: this.settings.logo_2_enabled },
            { url: this.settings.logo_url_3, enabled: this.settings.logo_3_enabled }
        ];
        
        let hasLogos = false;
        logos.forEach((logo, index) => {
            if (logo.enabled && logo.url && logo.url.trim() !== '') {
                const logoImg = document.createElement('img');
                logoImg.src = `/static/${logo.url}`;
                logoImg.alt = `Logo ${index + 1}`;
                logoImg.className = 'logo';
                logoImg.onerror = () => logoImg.style.display = 'none';
                logosContainer.appendChild(logoImg);
                hasLogos = true;
            }
        });
        
        // Set logo position
        if (hasLogos) {
            logoContainer.className = `logo-container ${this.settings.logo_position || 'top-left'}`;
            logoContainer.style.display = 'block';
        } else {
            logoContainer.style.display = 'none';
        }
    }

    async toggleLanguage() {
        this.language = this.language === 'en' ? 'es' : 'en';
        await this.loadTranslations();
        
        const langText = document.getElementById('langText');
        langText.textContent = this.language === 'en' ? 'ES' : 'EN';
        
        this.applySettings();
        this.refreshCurrentStep();
    }

    refreshCurrentStep() {
        const messages = document.getElementById('chatMessages');
        const lastMessage = messages.lastElementChild;
        if (lastMessage && lastMessage.classList.contains('bot')) {
            lastMessage.remove();
        }
        this.showCurrentStep();
    }

    startConversation() {
        setTimeout(() => {
            this.showMessage(this.translations.greeting.replace('counselors', this.settings.counselor_title), 'bot');
            this.currentStep = 1;
            setTimeout(() => this.showCurrentStep(), 1000);
        }, 1000);
    }

    showCurrentStep() {
        const step = this.steps[this.currentStep];
        
        switch (step) {
            case 'name':
                this.showInputField('name', this.translations.name_prompt, 'text', 'Enter your name');
                break;
            case 'email':
                this.showInputField('email', this.translations.email_prompt, 'email', 'Enter your email');
                break;
            case 'phone':
                this.showInputField('phone', this.translations.phone_prompt, 'tel', 'Enter your phone number');
                break;
            case 'dropdown':
                this.showDropdownField();
                break;
            case 'message':
                this.showTextareaField();
                break;
            case 'confirmation':
                this.showConfirmation();
                break;
        }
    }

    showMessage(text, sender) {
        const messages = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.textContent = text;
        messages.appendChild(messageDiv);
        messages.scrollTop = messages.scrollHeight;
    }

    showTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        indicator.style.display = 'flex';
        this.isTyping = true;
    }

    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        indicator.style.display = 'none';
        this.isTyping = false;
    }

    showInputField(fieldName, prompt, type, placeholder) {
        this.showTypingIndicator();
        
        setTimeout(() => {
            this.hideTypingIndicator();
            this.showMessage(prompt, 'bot');
            
            const inputContainer = document.getElementById('chatInputContainer');
            inputContainer.innerHTML = `
                <form class="chat-form">
                    <div class="input-group">
                        <input type="${type}" 
                               class="form-control" 
                               name="${fieldName}" 
                               placeholder="${placeholder}" 
                               required>
                        <button type="submit" class="btn btn-primary">
                            ${this.translations.send}
                        </button>
                    </div>
                </form>
            `;
            
            // Focus on input
            const input = inputContainer.querySelector('input');
            input.focus();
        }, 1500);
    }

    showDropdownField() {
        this.showTypingIndicator();
        
        setTimeout(() => {
            this.hideTypingIndicator();
            this.showMessage(this.translations.dropdown_prompt, 'bot');
            
            const options = this.settings.dropdown_options.map(option => 
                `<option value="${option}">${option}</option>`
            ).join('');
            
            const inputContainer = document.getElementById('chatInputContainer');
            inputContainer.innerHTML = `
                <form class="chat-form">
                    <div class="input-group">
                        <select class="form-select" name="dropdown_selection" required>
                            <option value="">Select an option</option>
                            ${options}
                        </select>
                        <button type="submit" class="btn btn-primary">
                            ${this.translations.send}
                        </button>
                    </div>
                </form>
            `;
            
            const select = inputContainer.querySelector('select');
            select.focus();
        }, 1500);
    }

    showTextareaField() {
        this.showTypingIndicator();
        
        setTimeout(() => {
            this.hideTypingIndicator();
            this.showMessage(this.translations.message_prompt, 'bot');
            
            const inputContainer = document.getElementById('chatInputContainer');
            inputContainer.innerHTML = `
                <form class="chat-form">
                    <div class="input-group">
                        <textarea class="form-control" 
                                  name="message" 
                                  rows="3" 
                                  placeholder="Type your message here..." 
                                  required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mt-2">
                        ${this.translations.submit}
                    </button>
                </form>
            `;
            
            const textarea = inputContainer.querySelector('textarea');
            textarea.focus();
        }, 1500);
    }

    showConfirmation() {
        this.showTypingIndicator();
        
        setTimeout(() => {
            this.hideTypingIndicator();
            const confirmationText = this.translations.confirmation + this.settings.phone_number;
            this.showMessage(confirmationText, 'bot');
            
            const inputContainer = document.getElementById('chatInputContainer');
            inputContainer.innerHTML = '';
            
            // Trigger confetti
            this.triggerConfetti();
            
            // Show success modal
            setTimeout(() => {
                this.showSuccessModal();
            }, 2000);
        }, 1500);
    }

    handleFormSubmission(form) {
        const formData = new FormData(form);
        const fieldName = form.querySelector('input, select, textarea').name;
        const value = formData.get(fieldName);
        
        if (!value.trim()) return;
        
        // Store form data
        this.formData[fieldName] = value;
        this.formData.language = this.language;
        
        // Show user message
        this.showMessage(value, 'user');
        
        // Move to next step
        this.currentStep++;
        
        if (this.currentStep < this.steps.length) {
            setTimeout(() => this.showCurrentStep(), 1000);
        } else {
            this.submitLead();
        }
    }

    handleButtonClick(button) {
        const action = button.dataset.action;
        
        if (action === 'continue') {
            this.isInterrupted = false;
            this.showCurrentStep();
        }
    }

    handleInterruption() {
        if (this.isInterrupted) return;
        
        this.isInterrupted = true;
        this.showMessage('?', 'user');
        
        setTimeout(() => {
            this.showMessage(this.translations.interruption_response, 'bot');
            
            const inputContainer = document.getElementById('chatInputContainer');
            inputContainer.innerHTML = `
                <button class="btn btn-secondary chat-btn" data-action="continue">
                    ${this.translations.yes}
                </button>
            `;
        }, 1000);
    }

    async submitLead() {
        try {
            const response = await fetch('/submit_lead', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams(this.formData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showConfirmation();
            } else {
                this.showMessage('Sorry, there was an error submitting your information. Please try again.', 'bot');
            }
        } catch (error) {
            console.error('Error submitting lead:', error);
            this.showMessage('Sorry, there was an error submitting your information. Please try again.', 'bot');
        }
    }

    triggerConfetti() {
        // Create confetti effect
        const duration = 3000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

        const randomInRange = (min, max) => Math.random() * (max - min) + min;

        const interval = setInterval(() => {
            const timeLeft = animationEnd - Date.now();

            if (timeLeft <= 0) {
                return clearInterval(interval);
            }

            const particleCount = 50 * (timeLeft / duration);
            
            // Since particles fall down, start a bit higher than random
            confetti(Object.assign({}, defaults, {
                particleCount,
                origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
            }));
            
            confetti(Object.assign({}, defaults, {
                particleCount,
                origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
            }));
        }, 250);
    }

    showSuccessModal() {
        const modal = new bootstrap.Modal(document.getElementById('successModal'));
        
        document.getElementById('successTitle').textContent = this.translations.success_title;
        document.getElementById('successMessage').textContent = this.translations.success_message;
        document.getElementById('contactInfo').textContent = this.translations.contact_info;
        document.getElementById('successOkBtn').textContent = 'OK';
        
        modal.show();
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ChatbotState();
});
